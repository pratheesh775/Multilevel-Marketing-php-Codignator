<?php 
include 'admin_header.php';
?>
 <div class="col-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Change Password</h4>
                    <?php echo form_open(base_url().'Password/change');?>
		
                    <?php 
                    foreach($result as $row)
                    {
                        $no=$row->mobileno;
                        } 
                        ?>
                      <label class="sr-only" for="inlineFormInputName2">Name</label>
                      <input type="text" required
                      class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="mobileno" readonly value="<?php echo $no;?>">
                      <label class="sr-only" for="inlineFormInputGroupUsername2">Username</label>
                      <div class="input-group mb-2 mr-sm-2">
                        <div class="input-group-prepend">
                          <div class="input-group-text">@</div>
                        </div>
                        <input type="text" required class="form-control" id="inlineFormInputGroupUsername2"
                        name="password" placeholder="New Password">
                      </div>
                      <div class="form-check mx-sm-2">
                        <label class="form-check-label">
                          <input type="checkbox" disabled  class="form-check-input" checked> Logout </label>
                      </div>
                      <input type="submit" value="Reset" name="submit" type="submit"
                       class="btn btn-gradient-primary mb-2">
                    </form>
                  </div>
                </div>
              </div>
             
<?php
include 'admin_footer.php';
?>