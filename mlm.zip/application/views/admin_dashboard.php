<?php
include 'admin_header.php';
?>
<div class="main-panel">
<!--
<div class="content-wrapper" >
            <div class="row" id="proBanner" >
              <div class="col-12">
                <span class="d-flex align-items-center purchase-popup">
                  <p>Permenant USER_ID</p>
                  <a  class="btn ml-auto download-button"><?php
    /*              $temp_id=$id;
                  $l=0;
                  foreach($result1 as $row)
                  {
                    if($temp_id == $row->user_id)
                    {
                         $row->left_name;
                        $row->right_name;
                       if($l == 0)
                       {
                       $temp_id=$row->right_id;
                        $l=1;
                      }
                       else
                       {
                       $temp_id=$row->right_id;
                       $l=0;
                      }
                }
                }
                
                echo 'Name:'. $name
                */?>
                
                </a>  <a class="btn purchase-button"><?php //echo $id ?></a>
                <i class="mdi mdi-close" id="bannerClose"></i>
                </span>
              </div>
            </div>
              -->


            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="mdi mdi-home"></i>
                </span> Dashboard </h3>
              <nav aria-label="breadcrumb">
                <ul class="breadcrumb">
                  <li class="breadcrumb-item active" aria-current="page">
                    <span></span><?php echo $id;?><i  class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                  </li>
                </ul>
              </nav>
            </div>
        




            <div class="row">
              <div class="col-md-4 stretch-card grid-margin">
                <div class="card bg-gradient-danger card-img-holder text-white">
                  <div class="card-body">
                    <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h4 class="font-weight-normal mb-3">Un-Settled Payment <i class="mdi mdi-bank mdi-48px float-right"></i>
                    </h4>
                    <h2 class="mb-5">
                    <?php
                    $cashcountl=0;
                    $cashcountr=0;
                    foreach($cash as $row9)
                    {
                      if($row9->right_id != '0')
                      {
                        $cashcountl++;
                      }
                      if($row9->left_id != '0')
                      {
                        $cashcountr++;
                      }
                    }
                    if($cashcountl != $cashcountr )
                    {
                              if($cashcountl > $cashcountr)
                                 echo "hai";
                                 else
                                 echo "not hai";    
                    }
                    ?>
                    
                    
                    </h2>
                    <h6 class="card-text"> Settlement Date:Each Month end</h6>
                  </div>
                </div>
              </div>
              <div class="col-md-4 stretch-card grid-margin">
                <div class="card bg-gradient-info card-img-holder text-white">
                  <div class="card-body">
                    <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h4 class="font-weight-normal mb-3">Total Any Time Earnings <i class="mdi mdi-cash-multiple mdi-48px float-right"></i>
                    </h4>
                    <h2 class="mb-5">
                    <?php
                    $cashcountl=0;
                    $cashcountr=0;

                    foreach($cash as $row9)
                    {
                      if($row9->right_id != '0')
                      {
                      echo  $cashcountl++;
                      }
                      if($row9->left_id != '0')
                      {
                       echo $cashcountr++;
                      }
                    }
                    echo $cashcountr;
                    ?>
                    
                    
                    
                    </h2>
                    <h6 class="card-text">rowarnings</h6>
                  </div>
                </div>
              </div>
              <div class="col-md-4 stretch-card grid-margin">
                <div class="card bg-gradient-success card-img-holder text-white">
                  <div class="card-body">
                    <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h4 class="font-weight-normal mb-3">My Chain Strength <i class="mdi mdi-account-multiple-outline  mdi-48px float-right"></i>
                    </h4>
                    <h2 class="mb-5">
                       <?php 
                       $count=0;
                       foreach($chainview as $wor)
                       {
                         $count++;
                       }
                       foreach($chainviewr as $wor)
                       {
                         $count++;
                       }
                       echo $count;
                       ?>
     




                    </h2>
                    <h6 class="card-text">Total members</h6>
                  </div>
                </div>
              </div>
            </div>
        








            <div class="row">
              <div class="col-md-12" >
              <div class="card">





</div>     
     
     
     
     
     
                            </div>
           
        
                        <div class="col-md-12 grid-margin stretch-card">
                <div class="card">

                <?php
     $count=-1;
     $id1=$id;
     $id3=$id;
     foreach($result1 as $row1)
     {
       if($id == $row1->user_id)
       {
       $count++;
       }
       $id=$row1->left_id;
      }
      $count1=-1;
     foreach($result1 as $row1)
     {
       if($id1 == $row1->user_id)
       {
       $count1++;
       }
       $id1=$row1->right_id;
      }
     
      //echo $count1;
     $dataPoints = array(
         array("label"=> "Left Level", "y"=> $count),
         array("label"=> "Right level", "y"=> $count1),
        );
         
     ?>
     <!DOCTYPE HTML>
     <html>
     <head>  
     <script>
     window.onload = function () {
      
     var chart = new CanvasJS.Chart("chartContainer", {
         animationEnabled: true,
         exportEnabled: true,
         title:{
             text: "Level Balance"
         },
         subtitles: [{
             text: "Over View"
         }],
         data: [{
             type: "pie",
             showInLegend: "true",
             legendText: "{label}",
             indexLabelFontSize: 16,
             indexLabel: "{label} - #percent% ",
             yValueFormatString: "Number:#,##0",
             dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
         }]
     });
     chart.render();
      
     }
     </script>
     </head>
     <body>
     <div id="chartContainer" style="height: 370px; width: 100%;"></div>
     <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
     </body>
     </html>       




              </div>
            </div>



            
            
                  <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Chain View </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Chain</a></li>
                  <li class="breadcrumb-item active" aria-current="page">My chain</li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Right Side </h4>
                    <p class="card-description"> Right side <code>Members</code>
                    </p>
                    <table class="table table-hover">
                      <thead>
                        <tr>

                          <th>Name</th>
                          <th>Contact</th>
                          <th>Left</th>
                          <th>Right</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php

                        foreach ($chainview as $row8)
                        {
                          echo "
                            <tr>
                            <td>$row8->username</td>
                          <td>$row8->mobile_no</td>";
                          ?>
 


                          <?php
                          if($row8->left_id =='')
                        {
                        ?>  
                          <td><label class="badge badge-danger">Empty</label></td>
                        <?php
                        }
                        else
                        {
                        ?>
                        <td><label class="badge-success"><?php echo $row8->left_name;?></label></td>
                      <?php
                        }
                        ?>



                          <?php
                          if($row8->right_id =='')
                        {
                        ?>  
                          <td><label class="badge badge-danger">Empty</label></td>
                        <?php
                        }
                        else
                        {
                        ?>
                        <td><label class="badge-success"><?php echo $row8->right_name;?></label></td>
                      <?php
                        }
                        ?>
 </tr>
                        <?php
                        }
                        ?>
                       <!-- <tr>
                          <td>Messsy</td>
                          <td>53275532</td>
                          <td>15 May 2017</td>
                          <td><label class="badge badge-warning">In progress</label></td>
                        </tr>
                        <tr>
                          <td>John</td>
                          <td>53275533</td>
                          <td>14 May 2017</td>
                          <td><label class="badge badge-info">Fixed</label></td>
                        </tr>
                        <tr>
                          <td>Peter</td>
                          <td>53275534</td>
                          <td>16 May 2017</td>
                          <td><label class="badge badge-success">Completed</label></td>
                        </tr>
                        <tr>
                          <td>Dave</td>
                          <td>53275535</td>
                          <td>20 May 2017</td>
                          <td><label class="badge badge-warning">In progress</label></td>
                        </tr>
                      --></tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="col-lg-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Left Side</h4>
                    <p class="card-description"> Left side <code>Members</code>
                    </p>
                    <table class="table table-hover">
                      <thead>
                      <tr>

<th>Name</th>
<th>Contact</th>
<th>Left</th>
<th>Right</th>
</tr>
</thead>
<tbody>
<?php

foreach ($chainviewr as $row8)
{
echo "
  <tr>
  <td>$row8->username</td>
<td>$row8->mobile_no</td>";
?>



<?php
if($row8->left_id =='')
{
?>  
<td><label class="badge badge-danger">Empty</label></td>
<?php
}
else
{
?>
<td><label class="badge-success"><?php echo $row8->left_id;?></label></td>
<?php
}
?>



<?php
if($row8->right_id =='')
{
?>  
<td><label class="badge badge-danger">Empty</label></td>
<?php
}
else
{
?>
<td><label class="badge-success"><?php echo $row8->right_id;?></label></td>
<?php
}
?>
</tr>
<?php
}
?>
</tbody>
                    </table>
                  </div>
                </div>
              </div>
         
            
            
            
                  <div class="d-flex mt-5 align-items-top">
                      <div class="mb-0 flex-grow">
                      </div>
                      <div class="ml-auto">
                        <i class="mdi mdi-heart-outline text-muted"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            





</div>

<?php
include 'admin_footer.php';
?>