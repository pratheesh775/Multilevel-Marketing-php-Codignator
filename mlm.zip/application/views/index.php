<?php
include 'header.php';
?>


<div id="content" class="content_home">
   <div class="so-page-builder">
      <div class="container page-builder-ltr">
         <div class="row row_rign row-style ">
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col_pn3e col-style slider-blc-img">
            <a href="<?php echo base_url();?>login">
                     
            <div class="<?php echo base_url();?>login">
                       <img src="images/click(1).jpg" class="img-margin">
                    
                    <br>
                </div>
                </a>
                <a href="<?php echo base_url();?>register">
                      
                <div class="crosseffect">
                        <img src="images/click2.jpg" class="mobile-margin" alt=" hai0">
                                    </div>
                                    </a>
</div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 col_104e col-style slider-blc-img">
               <div id="Atslideshow0" class="owl-carousel" style="opacity: 1;">
                  <div class="item">
                     <a href="index.html"><img src="images/slider-slide-2-880x737.jpg" alt="Banner2" class="img-responsive"></a>
                  </div>
                  <div class="item">
                     <a href="index.html"><img src="images/slider-slide-1-880x737.jpg" alt="Banner1" class="img-responsive"></a>
                  </div>
               </div>
               <script type="text/javascript"><!--
                  $('#Atslideshow0').owlCarousel({
                  
                  	items: 6,
                  
                  	autoPlay: 3000,
                  
                  	singleItem: true,
                  
                  	navigation: true,
                  
                  	navigationText: ['<i class="fa fa-chevron-left fa-5x">', '<i class="fa fa-chevron-right fa-5x">'],
                  
                  	pagination: false,
                  	transitionStyle : "fade"
                  
                  });
                  
                  -->
               </script>
            </div>
         </div>
      </div>
      <div class="container page-builder-ltr">
         <div class="row row_7keq row-style  ">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col_77nu col-style ">
               <div class="main-block-shipping">
                  <div class="block-img"><img src="images/Data-icon-1.png" style="width: 40px;"></div>
                  <div class="block-text">
                     <h4>Return &amp; Exchange</h4>
                     <p>committed to return the money in 30 days.</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col_xf4o col-style">
               <div class="main-block-shipping">
                  <div class="block-img"><img src="images/Data-icon-2.png" style="width: 40px;"></div>
                  <div class="block-text">
                     <h4>Receive Gift Card</h4>
                     <p>Receive gift all over order $50</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col_9v3t col-style ">
               <div class="main-block-shipping">
                  <div class="block-img"><img src="images/Data-icon-3.png" style="width: 40px;"></div>
                  <div class="block-text">
                     <h4>Online support 24/7</h4>
                     <p>Receive 24x7 online support</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="container page-builder-ltr">
         <div class="row row_obah row-style ">
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col_urjn col-style img-colum">
               <div class="crosseffect"><a href="#"><img src="images/Data-promo-3.png"></a><br></div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col_tf6r col-style img-colum">
               <div class="crosseffect"><a href="#"><img src="images/Data-promo-4.png"></a><br></div>
            </div>
            <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 col_fdnl col-style img-colum">
               <div class="crosseffect"><a href="#"><img src="images/Data-promo-5.png"></a></div>
            </div>
         </div>
      </div>
      <div class="container page-builder-ltr">
         <div class="row row_i0x6 row-style ">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col_5o1m col-style">
               <div class="trending-title">
                  <h3>Trending</h3>
                  <p>Most Trendy fashion</p>
                  <div class="border"></div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col_ejcq col-style trending-section">
               <div class="container">
                  <div class="section_title">
                     <h1 class="fp_carousel-title">Latest</h1>
                  </div>
                  <div class="tab-content">
                     <div class="product_carousel product-item owl-carousel owl-theme" id="latest_products_carousel">
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=50.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/product-Pendant700x700-012-228x228.jpg" alt="Adipiscing Elit" title="Adipiscing Elit" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('50');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('50');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('50');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=50.html">Adipiscing Elit</a></h5>
                                    <p class="price">
                                       <span class="price-new">$110.00</span> <span class="price-old">$122.00</span>
                                       <span class="price-tax">Ex Tax: $90.00</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=49.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/product-Pendant700x700-01-228x228.jpg" alt="Laoreet Dolore" title="Laoreet Dolore" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('49');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('49');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('49');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=49.html">Laoreet Dolore</a></h5>
                                    <p class="price">
                                       $241.99
                                       <span class="price-tax">Ex Tax: $199.99</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=48.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/Pendant-Pendant700x700-010-228x228.jpg" alt="Erat Volutpat" title="Erat Volutpat" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('48');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('48');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('48');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=48.html">Erat Volutpat</a></h5>
                                    <p class="price">
                                       $122.00
                                       <span class="price-tax">Ex Tax: $100.00</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=47.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/bracelet-bracelet700x700-04-228x228.jpg" alt="Andouille eu" title="Andouille eu" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('47');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=47.html">Andouille eu</a></h5>
                                    <p class="price">
                                       $122.00
                                       <span class="price-tax">Ex Tax: $100.00</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=46.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/product-Pendant700x700-02-228x228.jpg" alt="Lorem Ipsum" title="Lorem Ipsum" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('46');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('46');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('46');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=46.html">Lorem Ipsum</a></h5>
                                    <p class="price">
                                       <span class="price-new">$116.00</span> <span class="price-old">$1,202.00</span>
                                       <span class="price-tax">Ex Tax: $95.00</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=45.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/necklace-necklace700x700-04-228x228.jpg" alt="Fusce Aliquam" title="Fusce Aliquam" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('45');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('45');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('45');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=45.html">Fusce Aliquam</a></h5>
                                    <p class="price">
                                       $2,000.00
                                       <span class="price-tax">Ex Tax: $2,000.00</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <script type="text/javascript">
                  $(document).ready(function() {
                  
                  $('.product_carousel').owlCarousel({
                    items: 4, 
                    itemsDesktop : [1199,3],
                    itemsDesktopSmall : [979,3],
                    autoWidth:true,
                    pagination: false,
                    navigation:true,
                    navigationText: [
                      "<i class='fa fa-angle-left'>",
                      "<i class='fa fa-angle-right'>"
                    ],
                    });
                  
                  
                  });
                  
               </script>
               <div class="clear"></div>
            </div>
         </div>
      </div>
      <div class="container page-builder-ltr">
         <div class="row row_gkdd row-style  row-image">
            <div class="col-lg-3 col-md-3 col-sm-2 col-xs-12 col_7cx1 col-style">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-5 col-xs-12 col_hz0z col-style tablet-bg-top">
               <div class="align-left htmlimgtext">
                  <h3>November Sale</h3>
                  <p>Free shipping over $125 for international order.</p>
               </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-5 col-xs-12 col_uwea col-style tablet-bg-bottom">
               <div class="htmllink">
                  <a href="#">Shop Now</a>
               </div>
            </div>
         </div>
      </div>
      <div class="container page-builder-ltr">
         <div class="row row_ykun row-style row-image">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col_edn9 col-style">
               <div class="reviewblc">
                  <h1>Customers</h1>
                  <h2>reviews</h2>
                  <h5><i class="fa fa-times" aria-hidden="true"></i>Make your style cool<i class="fa fa-times" aria-hidden="true"></i></h5>
               </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 col_9j5g col-style">
               <div class="mod-testimonial_yrlx yt-clearfix  column-1 reviews-testimonial" style="">
                  <h3></h3>
                  <div id="testimonial_yrlx" class="yt-testimonial button-type2">
                     <div class="extraslider-inner" data-effect="fadeIn">
                        <div class="item">
                           <div class="item-wrap">
                              <div class="item-wrap-inner">
                                 <div class="item-img-info">
                                    <img class="img-responsive" src="images/Data-avtar.png" alt="John Doe" width="150" height="150">
                                 </div>
                                 <div class="item-info">
                                    Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.			
                                    <h5>John Doe</h5>
                                    <span class="position">PROJECT MANAGER</span>			
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="item">
                           <div class="item-wrap">
                              <div class="item-wrap-inner">
                                 <div class="item-img-info">
                                    <img class="img-responsive" src="images/Data-avtar.png" alt="John Doe" width="150" height="150">
                                 </div>
                                 <div class="item-info">
                                    Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.			
                                    <h5>John Doe</h5>
                                    <span class="position">PROJECT MANAGER</span>			
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <script type="text/javascript">
                     //<![CDATA[
                     jQuery(document).ready(function ($) {
                     	;(function (element) {
                     		var $element = $(element),
                     				$extraslider = $(".extraslider-inner", $element),
                     				_delay = 800,
                     				_duration = 500,
                     				_effect = "fadeIn";
                     
                     		$extraslider.on("initialized.owl.carousel", function () {
                     			var $item_active = $(".owl-item.active", $element);
                     			if ($item_active.length > 1 && _effect != "none") {
                     				_getAnimate($item_active);
                     			}
                     			else {
                     				var $item = $(".owl-item", $element);
                     				$item.css({"opacity": 1, "filter": "alpha(opacity = 100)"});
                     			}
                     			$(".owl-nav", $element).insertBefore($extraslider);
                     			$(".owl-controls", $element).insertAfter($extraslider);
                     			
                     		});
                     
                     		$extraslider.owlCarousel2({
                     		margin: 5,
                     		slideBy: 1,
                     		autoplay: true,
                     		autoplayHoverPause: true,
                     		autoplayTimeout: 5000,
                     		autoplaySpeed: 2000,
                     		startPosition: 0,
                     		mouseDrag: true,
                     		touchDrag: true,
                     		autoWidth: false,
                     		responsive: {
                     			0: 	{ items: 1 } ,
                     			480: { items: 1 },
                     			768: { items: 1 },
                     			992: { items: 1 },
                     			1200: {items: 1}
                     		},
                     			dotClass: "owl2-dot",
                     			dotsClass: "owl2-dots",
                     			dots: true,
                     			dotsSpeed:5000,
                     			nav: true,
                     			loop: true,
                     			navSpeed: 2000,
                     			navText: ["", ""],
                     			navClass: ["owl2-prev", "owl2-next"]
                     
                     		});
                     		function _getAnimate($el) {
                     			if (_effect == "none") return;
                     			//if ($.browser.msie && parseInt($.browser.version, 10) <= 9) return;
                     			$extraslider.removeClass("extra-animate");
                     			$el.each(function (i) {
                     				var $_el = $(this);
                     				$(this).css({
                     					"-webkit-animation": _effect + " " + _duration + "ms ease both",
                     					"-moz-animation": _effect + " " + _duration + "ms ease both",
                     					"-o-animation": _effect + " " + _duration + "ms ease both",
                     					"animation": _effect + " " + _duration + "ms ease both",
                     					"-webkit-animation-delay": +i * _delay + "ms",
                     					"-moz-animation-delay": +i * _delay + "ms",
                     					"-o-animation-delay": +i * _delay + "ms",
                     					"animation-delay": +i * _delay + "ms",
                     					"opacity": 1
                     				}).animate({
                     					opacity: 1
                     				});
                     
                     				if (i == $el.size() - 1) {
                     					$extraslider.addClass("extra-animate");
                     				}
                     			});
                     		}
                     
                     		function _UngetAnimate($el) {
                     			$el.each(function (i) {
                     				$(this).css({
                     					"animation": "",
                     					"-webkit-animation": "",
                     					"-moz-animation": "",
                     					"-o-animation": "",
                     					"opacity": 0
                     				});
                     			});
                     		}
                     
                     	})("#testimonial_yrlx");
                     });
                  </script>
               </div>
            </div>
         </div>
      </div>
      <div class="container page-builder-ltr">
         <div class="row row_ifii row-style hide ">
            <div class="col-lg-6 col-md-9 col-sm-9 col-xs-12 col_yif2 col-style fashion-block">
               <p><a href="#"><img src="images/Data-promo-2.jpg"></a><br></p>
            </div>
            <div class="col-lg-6 col-md-3 col-sm-3 col-xs-12 col_o92b col-img fashion-block">
               <p><a href="#"><img src="images/Data-promo-4.jpg"></a></p>
            </div>
         </div>
      </div>
      <div class="container page-builder-ltr">
         <div class="row row_ngco row-style hide ">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col_td1w col-style">
               <div class="container">
                  <div class="section_title">
                     <h1 class="fp_carousel-title">Our Products</h1>
                  </div>
                  <div id="tabs-0" class="htabs atproduct_tab">
                     <ul class="nav nav-tabs">
                        <li class="active">
                           <a href="#tab-featured-0" data-toggle="tab" class="selected">
                              <h5>Featured</h5>
                           </a>
                        </li>
                        <li>
                           <a href="#tab-bestseller-0" data-toggle="tab">
                              <h5>Bestseller</h5>
                           </a>
                        </li>
                        <li>
                           <a href="#tab-latest-0" data-toggle="tab">
                              <h5>Latest</h5>
                           </a>
                        </li>
                        <li>
                           <a href="#tab-special-0" data-toggle="tab">
                              <h5>Special</h5>
                           </a>
                        </li>
                     </ul>
                  </div>
                  <div class="tab-content">
                     <div id="tab-latest-0" class="tab-pane">
                        <div class="latest_products_carousel_tab product-item owl-carousel owl-theme" id="latest_products_carousel">
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=50.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/product-Pendant700x700-012-250x250.jpg" alt="Adipiscing Elit" title="Adipiscing Elit" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('50');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('50');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('50');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=50.html">Adipiscing Elit</a></h5>
                                       <p class="price">
                                          <span class="price-new">$110.00</span> <span class="price-old">$122.00</span>
                                          <span class="price-tax">Without tax: $90.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=49.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/product-Pendant700x700-01-250x250.jpg" alt="Laoreet Dolore" title="Laoreet Dolore" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('49');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('49');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('49');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=49.html">Laoreet Dolore</a></h5>
                                       <p class="price">
                                          $241.99
                                          <span class="price-tax">Without tax: $199.99</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=48.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/Pendant-Pendant700x700-010-250x250.jpg" alt="Erat Volutpat" title="Erat Volutpat" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('48');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('48');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('48');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=48.html">Erat Volutpat</a></h5>
                                       <p class="price">
                                          $122.00
                                          <span class="price-tax">Without tax: $100.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=47.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/bracelet-bracelet700x700-04-250x250.jpg" alt="Andouille eu" title="Andouille eu" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('47');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=47.html">Andouille eu</a></h5>
                                       <p class="price">
                                          $122.00
                                          <span class="price-tax">Without tax: $100.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div id="tab-featured-0" class="tab-pane active">
                        <div class="featured_products_carousel_tab product-item owl-carousel owl-theme" id="featured_products_carousel">
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=42.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/product-necklace700x700-04-250x250.jpg" alt="Accumsan Elit" title="Accumsan Elit" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('42');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=42.html">Accumsan Elit</a></h5>
                                       <p class="price">
                                          <span class="price-new">$90.00</span> <span class="price-old">$100.00</span>
                                          <span class="price-tax">Without tax: $90.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=32.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/necklace-necklace700x700-04-250x250.jpg" alt="Lorem Ipsum Passages" title="Lorem Ipsum Passages" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('32');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('32');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('32');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=32.html">Lorem Ipsum Passages</a></h5>
                                       <p class="price">
                                          <span class="price-new">$90.00</span> <span class="price-old">$100.00</span>
                                          <span class="price-tax">Without tax: $90.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=47.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/bracelet-bracelet700x700-04-250x250.jpg" alt="Andouille eu" title="Andouille eu" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('47');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=47.html">Andouille eu</a></h5>
                                       <p class="price">
                                          $122.00
                                          <span class="price-tax">Without tax: $100.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=30.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/bracelet-bracelet700x700-010-250x250.jpg" alt="Aliquam Consequat" title="Aliquam Consequat" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('30');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('30');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('30');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=30.html">Aliquam Consequat</a></h5>
                                       <p class="price">
                                          <span class="price-new">$98.00</span> <span class="price-old">$122.00</span>
                                          <span class="price-tax">Without tax: $80.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div id="tab-bestseller-0" class="tab-pane">
                        <div class="bestseller_products_carousel_tab product-item owl-carousel owl-theme" id="bestseller_products_carousel">
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=50.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/product-Pendant700x700-012-250x250.jpg" alt="Adipiscing Elit" title="Adipiscing Elit" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('50');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('50');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('50');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=50.html">Adipiscing Elit</a></h5>
                                       <p class="price">
                                          <span class="price-new">$110.00</span> <span class="price-old">$122.00</span>
                                          <span class="price-tax">Without tax: $90.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=47.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/bracelet-bracelet700x700-04-250x250.jpg" alt="Andouille eu" title="Andouille eu" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('47');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=47.html">Andouille eu</a></h5>
                                       <p class="price">
                                          $122.00
                                          <span class="price-tax">Without tax: $100.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=42.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/product-necklace700x700-04-250x250.jpg" alt="Accumsan Elit" title="Accumsan Elit" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('42');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=42.html">Accumsan Elit</a></h5>
                                       <p class="price">
                                          <span class="price-new">$90.00</span> <span class="price-old">$100.00</span>
                                          <span class="price-tax">Without tax: $90.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=49.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/product-Pendant700x700-01-250x250.jpg" alt="Laoreet Dolore" title="Laoreet Dolore" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('49');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('49');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('49');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=49.html">Laoreet Dolore</a></h5>
                                       <p class="price">
                                          $241.99
                                          <span class="price-tax">Without tax: $199.99</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div id="tab-special-0" class="tab-pane">
                        <div class="special_products_carousel_tab product-item owl-carousel owl-theme" id="special_products_carousel">
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=42.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/product-necklace700x700-04-250x250.jpg" alt="Accumsan Elit" title="Accumsan Elit" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('42');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=42.html">Accumsan Elit</a></h5>
                                       <p class="price">
                                          <span class="price-new">$90.00</span> <span class="price-old">$100.00</span>
                                          <span class="price-tax">Without tax: $90.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=50.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/product-Pendant700x700-012-250x250.jpg" alt="Adipiscing Elit" title="Adipiscing Elit" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('50');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('50');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('50');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=50.html">Adipiscing Elit</a></h5>
                                       <p class="price">
                                          <span class="price-new">$110.00</span> <span class="price-old">$122.00</span>
                                          <span class="price-tax">Without tax: $90.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=30.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/bracelet-bracelet700x700-010-250x250.jpg" alt="Aliquam Consequat" title="Aliquam Consequat" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('30');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('30');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('30');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=30.html">Aliquam Consequat</a></h5>
                                       <p class="price">
                                          <span class="price-new">$98.00</span> <span class="price-old">$122.00</span>
                                          <span class="price-tax">Without tax: $80.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="item">
                              <div class="product-layout">
                                 <div class="product-thumb transition">
                                    <div class="image product-image">
                                       <a href="product&amp;product_id=33.html">
                                          <div class="p-over p-grid-over"> </div>
                                          <div class="p-over p-grid-over1"> </div>
                                          <img src="images/earrings-earrings700x700-013-250x250.jpg" alt="Letraset Sheets" title="Letraset Sheets" class="img-responsive">
                                       </a>
                                       <div class="action">
                                          <div class="action_inner">
                                             <div class="button-group">
                                                <button type="button" onclick="cart.add('33');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                                <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('33');"><i class="fa fa-heart"></i></button>
                                                <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('33');"><i class="fa fa-exchange"></i></button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="caption">
                                       <h5><a href="product&amp;product_id=33.html">Letraset Sheets</a></h5>
                                       <p class="price">
                                          <span class="price-new">$116.00</span> <span class="price-old">$242.00</span>
                                          <span class="price-tax">Without tax: $95.00</span>
                                       </p>
                                       <div class="rating">
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                          <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <script type="text/javascript">
                  $(document).ready(function() {
                  
                  $('.featured_products_carousel_tab').owlCarousel({
                  	items: 4, 
                  	itemsDesktop : [1199,3],
                  	itemsDesktopSmall : [979,3],
                  	autoWidth:true,
                  	pagination: false,
                  	navigation:true,
                  	navigationText: [
                  		"<i class='fa fa-angle-left'>",
                  		"<i class='fa fa-angle-right'>"
                  	],
                  	});
                  
                  $('.latest_products_carousel_tab').owlCarousel({
                  	items: 4, 
                  	itemsDesktop : [1199,3],
                  	itemsDesktopSmall : [979,3],
                  	autoWidth:true,
                  	pagination: false,
                  	navigation:true,
                  	navigationText: [
                  		"<i class='fa fa-angle-left'>",
                  		"<i class='fa fa-angle-right'>"
                  	],
                  	});
                  
                  $('.bestseller_products_carousel_tab').owlCarousel({
                  	items: 4, 
                  	itemsDesktop : [1199,3],
                  	itemsDesktopSmall : [979,3],
                  	autoWidth:true,
                  	pagination: false,
                  	navigation:true,
                  	navigationText: [
                  		"<i class='fa fa-angle-left'>",
                  		"<i class='fa fa-angle-right'>"
                  	],
                  	});
                  
                  $('.special_products_carousel_tab').owlCarousel({
                  	items: 4, 
                  	itemsDesktop : [1199,3],
                  	itemsDesktopSmall : [979,3],
                  	autoWidth:true,
                  	pagination: false,
                  	navigation:true,
                  	navigationText: [
                  		"<i class='fa fa-angle-left'>",
                  		"<i class='fa fa-angle-right'>"
                  	],
                  	});
                  
                  
                  });
                  
               </script>
               <div class="clear"></div>
            </div>
         </div>
      </div>
      <div class="container-fluid page-builder-ltr">
         <div class="row row_u803 row-style hide ">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col_gjrf col-style">
               <div id="content_slider_gsyw" class="yt-content-slider owl2-theme yt-content-slider-style-default arrow-default " data-transitionin="fadeIn" data-transitionout="fadeOut" data-autoplay="yes" data-autoheight="yes" data-delay="4" data-speed="0.6" data-margin="0" data-items_column0="1" data-items_column1="1" data-items_column2="1" data-items_column3="1" data-items_column4="1" data-arrows="yes" data-pagination="no" data-lazyload="no" data-loop="yes" data-hoverpause="no">
                  <div class="yt-content-slide yt-clearfix yt-content-wrap"> <a href="#" title="" target="brank"><img src="images/slider-slide-1.png" alt="title_5eeafc5912e3613806241121592458329"></a></div>
                  <div class="yt-content-slide yt-clearfix yt-content-wrap"> <a href="#" title="" target="brank"><img src="images/slider-slide-2.png" alt="title_5eeafc5912e8614331825921592458329"></a></div>
               </div>
            </div>
         </div>
      </div>
      <div class="container-fluid page-builder-ltr">
         <div class="row row_kvg7 row-style hide ">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col_5tmy col-style">
               <div id="Atslideshow1" class="owl-carousel" style="opacity: 1;">
                  <div class="item">
                     <a href="index.html"><img src="images/slider-slide-1-880x737.jpg" alt="Banner2" class="img-responsive"></a>
                  </div>
                  <div class="item">
                     <a href="index.html"><img src="images/slider-slide-2-880x737.jpg" alt="Banner1" class="img-responsive"></a>
                  </div>
               </div>
               <script type="text/javascript"><!--
                  $('#Atslideshow1').owlCarousel({
                  
                  	items: 6,
                  
                  	autoPlay: 3000,
                  
                  	singleItem: true,
                  
                  	navigation: true,
                  
                  	navigationText: ['<i class="fa fa-chevron-left fa-5x">', '<i class="fa fa-chevron-right fa-5x">'],
                  
                  	pagination: false,
                  	transitionStyle : "fade"
                  
                  });
                  
                  -->
               </script>
            </div>
         </div>
      </div>
      <div class="container page-builder-ltr">
         <div class="row row_kzvf row-style hide ">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col_9ams col-style">
               <div class="trending-title">
                  <h3>Weekly Featured</h3>
                  <p>Most Trendy fashion</p>
                  <div class="border"></div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col_c9ps col-style trending-section">
               <div class="container">
                  <div class="section_title">
                     <h1 class="fp_carousel-title">Featured</h1>
                  </div>
                  <div class="tab-content">
                     <div class="product_carousel product-item owl-carousel owl-theme" id="latest_products_carousel">
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=42.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/product-necklace700x700-04-250x250.jpg" alt="Accumsan Elit" title="Accumsan Elit" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('42');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=42.html">Accumsan Elit</a></h5>
                                    <p class="price">
                                       <span class="price-new">$90.00</span> <span class="price-old">$100.00</span>
                                       <span class="price-tax">Ex Tax: $90.00</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=30.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/bracelet-bracelet700x700-010-250x250.jpg" alt="Aliquam Consequat" title="Aliquam Consequat" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('30');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('30');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('30');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=30.html">Aliquam Consequat</a></h5>
                                    <p class="price">
                                       <span class="price-new">$98.00</span> <span class="price-old">$122.00</span>
                                       <span class="price-tax">Ex Tax: $80.00</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=47.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/bracelet-bracelet700x700-04-250x250.jpg" alt="Andouille eu" title="Andouille eu" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('47');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=47.html">Andouille eu</a></h5>
                                    <p class="price">
                                       $122.00
                                       <span class="price-tax">Ex Tax: $100.00</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="item">
                           <div class="product-layout">
                              <div class="product-thumb transition">
                                 <div class="image product-image">
                                    <a href="product&amp;product_id=28.html">
                                       <div class="p-over p-grid-over"> </div>
                                       <div class="p-over p-grid-over1"> </div>
                                       <img src="images/ring-ring700x700-010-250x250.jpg" alt="Bima zuma" title="Bima zuma" class="img-responsive">
                                    </a>
                                    <div class="action">
                                       <div class="action_inner">
                                          <div class="button-group">
                                             <button type="button" onclick="cart.add('28');" class="cart_button" data-toggle="tooltip" title="Add to Cart"> <i class="fa fa-shopping-bag"></i></button>
                                             <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to wishlist" onclick="wishlist.add('28');"><i class="fa fa-heart"></i></button>
                                             <button type="button" class="compare_button" data-toggle="tooltip" title="Compare" onclick="compare.add('28');"><i class="fa fa-exchange"></i></button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="caption">
                                    <h5><a href="product&amp;product_id=28.html">Bima zuma</a></h5>
                                    <p class="price">
                                       $122.00
                                       <span class="price-tax">Ex Tax: $100.00</span>
                                    </p>
                                    <div class="rating">
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                       <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <script type="text/javascript">
                  $(document).ready(function() {
                  
                  $('.product_carousel').owlCarousel({
                    items: 4, 
                    itemsDesktop : [1199,3],
                    itemsDesktopSmall : [979,3],
                    autoWidth:true,
                    pagination: false,
                    navigation:true,
                    navigationText: [
                      "<i class='fa fa-angle-left'>",
                      "<i class='fa fa-angle-right'>"
                    ],
                    });
                  
                  
                  });
                  
               </script>
               <div class="clear"></div>
            </div>
         </div>
      </div>
      <div class="container page-builder-ltr">
         <div class="row row_5twi row-style hide ">
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col_la8o col-style img-colum">
               <p><a href="#"><img src="images/Data-banner-1.jpg"></a><br></p>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col_2f89 col-style img-colum">
               <p><a href="#"><img src="images/Data-banner2.jpg"></a><br></p>
            </div>
            <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 col_hd1i col-style img-colum">
               <p><a href="#"><img src="images/Data-banner-3.jpg"></a></p>
            </div>
         </div>
      </div>
   </div>
   <script>
      function subscribe()
      
      {
      
          var emailpattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      
          var email = $('#txtemail').val();
          var name = $('#txtname').val();
      
          if (email != "" && name != "")
      
          {
      
              if (!emailpattern.test(email))
      
              {
      
                  alert("Invalid Email");
      
                  $('#txtemail').focus();
      
                  return false;
      
              } else
      
              {
      
                  $.ajax({
      
                      url: 'index.php?route=extension/module/atnewsletters/news',
      
                      type: 'post',
      
                      data: 'email=' + $('#txtemail').val(),
      
                      dataType: 'json',
      
                      success: function(json) {
      
                          alert(json.message);
                          $('#mail-box form').each(function() {
                              this.reset();
                          });
      
                      }
      
                  });
                  return false;
      
              }
      
          } else
      
          {
      
              //document.write("Name & Email Is Require");
      
              alert("Name or Email is missing");
      
              $('#txtname').focus();
      
              return false;
      
          }
      
      }
   </script>
   <div class="newsletter_section">
      <div class="container">
         <div class="row">
            <div class="col-sm-12 col-xs-12">
               <div class="newsletter_title">
                  <h1>Newsletter</h1>
               </div>
            </div>
            <div class="col-sm-12 col-xs-12">
               <div id="advanced-atnewsletter-box">
                  <h2 class="heading-title"><span>Subscribe to us</span></h2>
                  <div class="input-group box-atnewsletter-subscribe newsletter" id="mail-box">
                     <form action="/" method="post" class="form-inline">
                        <div class="form-group required">
                           <input type="text" name="txtname" id="txtname" value="" placeholder="Enter Your Name" class="form-control input-lg"><input type="email" name="txtemail" id="txtemail" value="" placeholder="Enter Your Email" class="form-control input-lg"><button type="submit" class="btn btn-default btn-lg" onclick="return subscribe();">
                           Submit                                </button>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>


<?php
include 'footer.php';
?>