<!DOCTYPE html>
<!--[if IE]><![endif]--><!--[if IE 8 ]>
<html dir="ltr" lang="en" class="ie8">
   <![endif]--><!--[if IE 9 ]>
   <html dir="ltr" lang="en" class="ie9">
      <![endif]--><!--[if (gt IE 9)|!(IE)]><!-->
      <html dir="ltr" lang="en">
         <!--<![endif]-->
         <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <title>Any-Time</title>
            <base href="<?php echo base_url();?>">
            <meta name="description" content="Minimal Store">
            <script src="js/jquery-jquery-2.1.1.min.js" type="text/javascript"></script>
            <link href="<?php echo base_url();?>css/css-bootstrap.min.css" rel="stylesheet" media="screen">
            <script src="js/js-bootstrap.min.js" type="text/javascript" defer></script><script src="js/owl-carousel-owl.carousel.min.js" type="text/javascript"></script>
            <link href="<?php echo base_url();?>css/owl-carousel-owl.carousel.css" rel="stylesheet" media="screen">
            <link href="<?php echo base_url();?>css/owl-carousel-owl.transitions.css" rel="stylesheet" media="screen">
            <script src="js/at-jquery.custom.min.js" type="text/javascript"></script><script src="js/at-custom.js" type="text/javascript"></script>
            <link href="<?php echo base_url();?>css/css-font-awesome.min.css" rel="stylesheet" type="text/css">
            <link href="<?php echo base_url();?>https://fonts.googleapis.com/css?family=Open+Sans%7CPoppins:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
            <link href="<?php echo base_url();?>css/stylesheet-atstyle.css" rel="stylesheet">
            <link href="<?php echo base_url();?>css/css-shortcodes.css" type="text/css" rel="stylesheet" media="screen">
            <link href="<?php echo base_url();?>css/css-animate.css" type="text/css" rel="stylesheet" media="screen">
            <link href="<?php echo base_url();?>css/css-owl.carousel.css" type="text/css" rel="stylesheet" media="screen">
            <link href="<?php echo base_url();?>css/css-style.css" type="text/css" rel="stylesheet" media="screen">
            <link href="<?php echo base_url();?>css/css-gallery.css" type="text/css" rel="stylesheet" media="screen">
            <link href="<?php echo base_url();?>css/css-content_slider.css" type="text/css" rel="stylesheet" media="screen">
            <link href="<?php echo base_url();?>css/css-style_render_60.css" type="text/css" rel="stylesheet" media="screen">
            <link href="<?php echo base_url();?>css/css-style.css" type="text/css" rel="stylesheet" media="screen">
            <script src="js/javascript-common.js" type="text/javascript"></script>
            <link href="<?php echo base_url();?>favicons/catalog-cart.png" rel="icon">
            <script src="js/js-shortcodes.js" type="text/javascript"></script><script src="js/js-owl.carousel.js" type="text/javascript"></script><script src="js/js-jquery.prettyPhoto.js" type="text/javascript"></script><script src="js/js-content_slider.js" type="text/javascript"></script><script src="js/js-section.js" type="text/javascript"></script><script src="js/js-modernizr.video.js" type="text/javascript"></script><script src="js/js-swfobject.js" type="text/javascript"></script><script src="js/js-video_background.js" type="text/javascript"></script>
         </head>
         <body class="common-home">
            <header>
               <div class="header_outer">
                  <div class="top-bar">
                     <div class="container">
                        <div class="row">
                           <div class="col-sm-7 col-xs-8  no-space">
                              <div class="container headermodule">
                                 <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-9 atheader1">
                                       Contact us on <a href="<?php echo base_url();?>tel:+1234567890">123 456 7890 </a>or&nbsp;<a href="<?php echo base_url();?>
                                       mailto:info@demo.com">info@anytime.com</a>      
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-5 col-xs-4">
                              <div class="header_right">
                                 <div class="currency_div">
                                    <form action="https://opencartdemo.multipurposethemes.com/oc015/oc01/index.php?route=common/currency/currency" method="post" enctype="multipart/form-data" id="currency">
                                       <div class="btn-group">
                                          <button class="btn btn-link dropdown-toggle" data-toggle="dropdown">
                                          <strong>$</strong>
                                          <span class="hidden-xs hidden-sm hidden-md">Currency</span> <i class="fa fa-angle-down"></i></button>
                                       </div>
                                       <input type="hidden" name="code" value=""><input type="hidden" name="redirect" value="https://opencartdemo.multipurposethemes.com/oc015/oc01/index.php?route=common/home">
                                    </form>
                                 </div>
                                 <div id="cart" class="btn-group btn-block">
                                    <button type="button" data-toggle="dropdown" data-loading-text="Loading..." class="btn btn-inverse btn-block btn-lg dropdown-toggle"><i class="fa fa-shopping-bag"></i> <span id="cart-total" class="hidden-xs">0 item(s) - $0.00</span></button>
                                    <ul class="dropdown-menu pull-right">
                                       <li>
                                          <p class="text-center">Your shopping cart is empty!</p>
                                       </li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="header">
                     <div class="container">
                        <div class="row">
                           <div class="col-sm-3">
                              <div id="logo">
                                 <a href="<?php echo base_url();?>"><img src="images/lg.png" title="Minimal Store" alt="Minimal Store" class="img-responsive"></a>
                              </div>
                           </div>
                           <div class="col-sm-6">
                              <div class="search_outer_toggle">
                                 <div id="search" class="input-group">
                                    <input type="text" name="search" value="" placeholder="Search" class="form-control input-lg"><span class="input-group-btn">
                                    <button type="button" class="btn btn-default btn-lg"><i class="fa fa-search"></i></button>
                                    </span>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-3 header_right">
                              <div class="menu_right cart">
                                 <div id="cart" class="btn-group btn-block">
                                    <button type="button" data-toggle="dropdown" data-loading-text="Loading..." class="btn btn-inverse btn-block btn-lg dropdown-toggle"><i class="fa fa-shopping-bag"></i> <span id="cart-total" class="hidden-xs">0 item(s) - $0.00</span></button>
                                    <ul class="dropdown-menu pull-right">
                                       <li>
                                          <p class="text-center">Your shopping cart is empty!</p>
                                       </li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="menu_outer">
                     <div class="container">
                        <div class="row">
                           <div class="col-md-12">
                              <link href="<?php echo base_url();?>css/so_megamenu-so_megamenu.css" rel="stylesheet" type="text/css">
                              <link href="<?php echo base_url();?>css/so_megamenu-wide-grid.css" rel="stylesheet" type="text/css">
                              <script src="js/so_megamenu-so_megamenu.js" type="text/javascript"></script>
                              <div class="col-md-9 col-xs-2 no-space">
                                 <div class="megamenu">
                                    <div class="responsive">
                                       <nav class="navbar-default">
                                          <div class=" container-megamenu  horizontal">
                                             <div class="navbar-header">
                                                <button type="button" id="show-megamenu" data-toggle="collapse" class="navbar-toggle">
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                                </button>
                                             </div>
                                             <div class="megamenu-wrapper">
                                                <span id="remove-megamenu" class="fa fa-times"></span>
                                                <div class="megamenu-pattern">
                                                   <div class="container">
                                                      <ul class="megamenu" data-transition="slide" data-animationtime="500">
                                                         <li class="">
                                                            <p class="close-menu"></p>
                                                            <a href="<?php echo base_url();?>" class="clearfix">
                                                            <strong>
                                                            Home
                                                            </strong>
                                                            </a>
                                                         </li>
                                                         <li class=" with-sub-menu hover">
                                                            <p class="close-menu"></p>
                                                            <a href="<?php echo base_url();?>products" class="clearfix">
                                                            <strong>
                                                            <i class="fa fa-plane"></i>Products
                                                            </strong>
                                                       <!---     <span class="label"> New</span>
                                    --><b class="caret"></b>
                                                            </a>
                                                            <div class="sub-menu" style="width:100%">
                                                               <div class="content">
                                                                  <div class="row">
                                                                     <div class="col-sm-12">
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=42.html">
                                                                                 <img src="images/product-necklace700x700-04-100x100.jpg" alt="Accumsan Elit" title="Accumsan Elit" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=42.html">Accumsan Elit</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price"><span class="price-new">$90.00</span> <span class="price-old">$100.00</span><span class="price-tax">$90.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=48.html">
                                                                                 <img src="images/Pendant-Pendant700x700-010-100x100.jpg" alt="Erat Volutpat" title="Erat Volutpat" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=48.html">Erat Volutpat</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price">$122.00<span class="price-tax">$100.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=50.html">
                                                                                 <img src="images/product-Pendant700x700-012-100x100.jpg" alt="Adipiscing Elit" title="Adipiscing Elit" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=50.html">Adipiscing Elit</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price"><span class="price-new">$110.00</span> <span class="price-old">$122.00</span><span class="price-tax">$90.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=36.html">
                                                                                 <img src="images/earrings-earrings700x700-014-100x100.jpg" alt="Etiam Gravida" title="Etiam Gravida" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=36.html">Etiam Gravida</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price">$122.00<span class="price-tax">$100.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=47.html">
                                                                                 <img src="images/bracelet-bracelet700x700-04-100x100.jpg" alt="Andouille eu" title="Andouille eu" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=47.html">Andouille eu</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price">$122.00<span class="price-tax">$100.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=41.html">
                                                                                 <img src="images/necklace-necklace700x700-02-100x100.jpg" alt="Dail miren tukan" title="Dail miren tukan" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=41.html">Dail miren tukan</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price">$122.00<span class="price-tax">$100.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=30.html">
                                                                                 <img src="images/bracelet-bracelet700x700-010-100x100.jpg" alt="Aliquam Consequat" title="Aliquam Consequat" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=30.html">Aliquam Consequat</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price"><span class="price-new">$98.00</span> <span class="price-old">$122.00</span><span class="price-tax">$80.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=28.html">
                                                                                 <img src="images/ring-ring700x700-010-100x100.jpg" alt="Bima zuma" title="Bima zuma" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=28.html">Bima zuma</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price">$122.00<span class="price-tax">$100.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                     </div>
                                                                  </div>
                                                                  <div class="border"></div>
                                                                  <div class="row">
                                                                     <div class="col-sm-12">
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=42.html">
                                                                                 <img src="images/product-necklace700x700-04-100x100.jpg" alt="Accumsan Elit" title="Accumsan Elit" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=42.html">Accumsan Elit</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price"><span class="price-new">$90.00</span> <span class="price-old">$100.00</span><span class="price-tax">$90.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=50.html">
                                                                                 <img src="images/product-Pendant700x700-012-100x100.jpg" alt="Adipiscing Elit" title="Adipiscing Elit" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=50.html">Adipiscing Elit</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price"><span class="price-new">$110.00</span> <span class="price-old">$122.00</span><span class="price-tax">$90.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=30.html">
                                                                                 <img src="images/bracelet-bracelet700x700-010-100x100.jpg" alt="Aliquam Consequat" title="Aliquam Consequat" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=30.html">Aliquam Consequat</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price"><span class="price-new">$98.00</span> <span class="price-old">$122.00</span><span class="price-tax">$80.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                        <div class="col-sm-3 ">
                                                                           <div class="product-thumb">
                                                                              <div class="image">
                                                                                 <a href="<?php echo base_url();?>product&amp;product_id=33.html">
                                                                                 <img src="images/earrings-earrings700x700-013-100x100.jpg" alt="Letraset Sheets" title="Letraset Sheets" class="img-responsive"></a>
                                                                              </div>
                                                                              <div>
                                                                                 <div class="caption">
                                                                                    <h4><a href="<?php echo base_url();?>product&amp;product_id=33.html">Letraset Sheets</a></h4>
                                                                                    <p>Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                                                                                       mattis vulputate, tristique ut leà...
                                                                                    </p>
                                                                                    <p class="price"><span class="price-new">$116.00</span> <span class="price-old">$242.00</span><span class="price-tax">$95.00</span></p>
                                                                                 </div>
                                                                              </div>
                                                                           </div>
                                                                        </div>
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                         </li>
                                                         <li class=" with-sub-menu hover">
                                                            <p class="close-menu"></p>
                                                            <a href="<?php echo base_url();?>aboutus" class="clearfix">
                                                            <strong>
                                                            About-Us
                                                            </strong>
                                                            </a>
                                                             </li>
                                                         <li class="">
                                                            <p class="close-menu"></p>
                                                            <a href="<?php echo base_url();?>contactus" class="clearfix">
                                                            <strong>
                                                            <i class="fa fa-fire"></i>Contact Us
                                                            </strong>
                                                       <!---     <span class="label"> Click here</span>
                                                            ---></a>
                                                         </li>
                                                      </ul>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </nav>
                                    </div>
                                    <script>
                                       $(document).ready(function(){
                                       	$('a[href="<?php echo base_url();?><?php echo base_url();?>"]').each(function() {
                                       		$(this).parents('.with-sub-menu').addClass('sub-active');
                                       	});  
                                       });
                                    </script>
                                 </div>
                              </div>
                              <div class="col-md-3 col-xs-10">
                                 <div class="menu_right">
                                    <a href="<?php echo base_url();?>register">Register</a><span class="menu-separator">/</span>
                                    <a href="<?php echo base_url();?>login">Login</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </header>

