<?php
include 'header.php';
?>

<div class="container">
   <ul class="breadcrumb">
      <li>
         <a href="<?php echo base_url();?>">
         <i class="fa fa-home"></i>			</a>
      </li>
      <li>
         <a>
         products			</a>
      </li>
   </ul>
   <div class="row">
         <br>
         <div class="row">
            <div class="product-layout product-list col-xs-12">
               <div class="product-thumb">
                  <div class="image product-image">
                     <a href="product&amp;path=33&amp;product_id=42.html">
                     <img src="images/new/6.jpeg" alt="
                        Accumsan Elit" title="
                        Accumsan Elit" class="img-responsive"></a>
                     <div class="action">
                        <div class="action_inner">
                           <div class="button-group">
                              <button class="wishlist_button" type="button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('42');"><i class="fa fa-heart"></i>
                              </button>
                              <button class="compare_button" type="button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('42');"><i class="fa fa-exchange"></i>
                              </button>
                              <button class="cart_button" type="button" onclick="cart.add('42', '2');"><i class="fa fa-shopping-bag"></i>
                              </button>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div>
                     <div class="caption">
                        <h5>
                           <a href="product&amp;path=33&amp;product_id=42.html">
                           Accumsan Elit										</a>
                        </h5>
                        <p class="desc">
                           Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                           mattis vulputate, tristique ut..									
                        </p>
                        <p class="price">
                           <span class="price-new">
                           $90.00										</span>
                           <span class="price-old">
                           $100.00										</span>
                           <span class="price-tax">
                           Ex Tax:											$90.00										</span>
                        </p>
                        <div class="rating">
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                        </div>
                     </div>
                     <div class="addtolinks_list">
                        <div class="button-group">
                           <button type="button" onclick="cart.add('42');" class="" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-bag"></i><span class="hidden-xs hidden-sm hidden-md cart-icon">Add to Cart</span>
                           </button>
                           <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
                           <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="product-layout product-list col-xs-12">
               <div class="product-thumb">
                  <div class="image product-image">
                     <a href="product&amp;path=33&amp;product_id=50.html">
                     <img src="images/new/2.jpeg" alt="
                        Adipiscing Elit" title="
                        Adipiscing Elit" class="img-responsive"></a>
                     <div class="action">
                        <div class="action_inner">
                           <div class="button-group">
                              <button class="wishlist_button" type="button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('50');"><i class="fa fa-heart"></i>
                              </button>
                              <button class="compare_button" type="button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('50');"><i class="fa fa-exchange"></i>
                              </button>
                              <button class="cart_button" type="button" onclick="cart.add('50', '2');"><i class="fa fa-shopping-bag"></i>
                              </button>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div>
                     <div class="caption">
                        <h5>
                           <a href="product&amp;path=33&amp;product_id=50.html">
                           Adipiscing Elit										</a>
                        </h5>
                        <p class="desc">
                           Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                           mattis vulputate, tristique ut..									
                        </p>
                        <p class="price">
                           <span class="price-new">
                           $110.00										</span>
                           <span class="price-old">
                           $122.00										</span>
                           <span class="price-tax">
                           Ex Tax:											$90.00										</span>
                        </p>
                        <div class="rating">
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                        </div>
                     </div>
                     <div class="addtolinks_list">
                        <div class="button-group">
                           <button type="button" onclick="cart.add('50');" class="" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-bag"></i><span class="hidden-xs hidden-sm hidden-md cart-icon">Add to Cart</span>
                           </button>
                           <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('50');"><i class="fa fa-heart"></i></button>
                           <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('50');"><i class="fa fa-exchange"></i></button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="product-layout product-list col-xs-12">
               <div class="product-thumb">
                  <div class="image product-image">
                     <a href="product&amp;path=33&amp;product_id=30.html">
                     <img src="images/new/3.jepg" alt="
                        Aliquam Consequat" title="
                        Aliquam Consequat" class="img-responsive"></a>
                     <div class="action">
                        <div class="action_inner">
                           <div class="button-group">
                              <button class="wishlist_button" type="button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('30');"><i class="fa fa-heart"></i>
                              </button>
                              <button class="compare_button" type="button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('30');"><i class="fa fa-exchange"></i>
                              </button>
                              <button class="cart_button" type="button" onclick="cart.add('30', '1');"><i class="fa fa-shopping-bag"></i>
                              </button>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div>
                     <div class="caption">
                        <h5>
                           <a href="product&amp;path=33&amp;product_id=30.html">
                           Aliquam Consequat										</a>
                        </h5>
                        <p class="desc">
                           Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                           mattis vulputate, tristique ut..									
                        </p>
                        <p class="price">
                           <span class="price-new">
                           $98.00										</span>
                           <span class="price-old">
                           $122.00										</span>
                           <span class="price-tax">
                           Ex Tax:											$80.00										</span>
                        </p>
                        <div class="rating">
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                        </div>
                     </div>
                     <div class="addtolinks_list">
                        <div class="button-group">
                           <button type="button" onclick="cart.add('30');" class="" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-bag"></i><span class="hidden-xs hidden-sm hidden-md cart-icon">Add to Cart</span>
                           </button>
                           <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('30');"><i class="fa fa-heart"></i></button>
                           <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('30');"><i class="fa fa-exchange"></i></button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="product-layout product-list col-xs-12">
               <div class="product-thumb">
                  <div class="image product-image">
                     <a href="product&amp;path=33&amp;product_id=47.html">
                     <img src="images/new/4.jpeg" alt="
                        Andouille eu" title="
                        Andouille eu" class="img-responsive"></a>
                     <div class="action">
                        <div class="action_inner">
                           <div class="button-group">
                              <button class="wishlist_button" type="button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('47');"><i class="fa fa-heart"></i>
                              </button>
                              <button class="compare_button" type="button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('47');"><i class="fa fa-exchange"></i>
                              </button>
                              <button class="cart_button" type="button" onclick="cart.add('47', '1');"><i class="fa fa-shopping-bag"></i>
                              </button>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div>
                     <div class="caption">
                        <h5>
                           <a href="product&amp;path=33&amp;product_id=47.html">
                           Andouille eu										</a>
                        </h5>
                        <p class="desc">
                           Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                           mattis vulputate, tristique ut..									
                        </p>
                        <p class="price">
                           $122.00																														<span class="price-tax">
                           Ex Tax:											$100.00										</span>
                        </p>
                        <div class="rating">
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                        </div>
                     </div>
                     <div class="addtolinks_list">
                        <div class="button-group">
                           <button type="button" onclick="cart.add('47');" class="" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-bag"></i><span class="hidden-xs hidden-sm hidden-md cart-icon">Add to Cart</span>
                           </button>
                           <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
                           <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="product-layout product-list col-xs-12">
               <div class="product-thumb">
                  <div class="image product-image">
                     <a href="product&amp;path=33&amp;product_id=28.html">
                     <img src="images/new/5.jpeg" alt="
                        Bima zuma" title="
                        Bima zuma" class="img-responsive"></a>
                     <div class="action">
                        <div class="action_inner">
                           <div class="button-group">
                              <button class="wishlist_button" type="button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('28');"><i class="fa fa-heart"></i>
                              </button>
                              <button class="compare_button" type="button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('28');"><i class="fa fa-exchange"></i>
                              </button>
                              <button class="cart_button" type="button" onclick="cart.add('28', '1');"><i class="fa fa-shopping-bag"></i>
                              </button>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div>
                     <div class="caption">
                        <h5>
                           <a href="product&amp;path=33&amp;product_id=28.html">
                           Bima zuma										</a>
                        </h5>
                        <p class="desc">
                           Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                           mattis vulputate, tristique ut..									
                        </p>
                        <p class="price">
                           $122.00																														<span class="price-tax">
                           Ex Tax:											$100.00										</span>
                        </p>
                        <div class="rating">
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                        </div>
                     </div>
                     <div class="addtolinks_list">
                        <div class="button-group">
                           <button type="button" onclick="cart.add('28');" class="" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-bag"></i><span class="hidden-xs hidden-sm hidden-md cart-icon">Add to Cart</span>
                           </button>
                           <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('28');"><i class="fa fa-heart"></i></button>
                           <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('28');"><i class="fa fa-exchange"></i></button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="product-layout product-list col-xs-12">
               <div class="product-thumb">
                  <div class="image product-image">
                     <a href="product&amp;path=33&amp;product_id=41.html">
                     <img src="images/new/6.jpeg" alt="
                        Dail miren tukan" title="
                        Dail miren tukan" class="img-responsive"></a>
                     <div class="action">
                        <div class="action_inner">
                           <div class="button-group">
                              <button class="wishlist_button" type="button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('41');"><i class="fa fa-heart"></i>
                              </button>
                              <button class="compare_button" type="button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('41');"><i class="fa fa-exchange"></i>
                              </button>
                              <button class="cart_button" type="button" onclick="cart.add('41', '1');"><i class="fa fa-shopping-bag"></i>
                              </button>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div>
                     <div class="caption">
                        <h5>
                           <a href="product&amp;path=33&amp;product_id=41.html">
                           Dail miren tukan										</a>
                        </h5>
                        <p class="desc">
                           Nunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et 
                           mattis vulputate, tristique ut..									
                        </p>
                        <p class="price">
                           $122.00																														<span class="price-tax">
                           Ex Tax:											$100.00										</span>
                        </p>
                        <div class="rating">
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                           <span class="fa fa-stack">
                           <i class="fa fa-star fa-stack-2x"></i>
                           </span>
                        </div>
                     </div>
                     <div class="addtolinks_list">
                        <div class="button-group">
                           <button type="button" onclick="cart.add('41');" class="" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-bag"></i><span class="hidden-xs hidden-sm hidden-md cart-icon">Add to Cart</span>
                           </button>
                           <button type="button" class="wishlist_button" data-toggle="tooltip" title="Add to Wish List" onclick="wishlist.add('41');"><i class="fa fa-heart"></i></button>
                           <button type="button" class="compare_button" data-toggle="tooltip" title="Compare this Product" onclick="compare.add('41');"><i class="fa fa-exchange"></i></button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-md-8 col-sm-8 col-xs-12 text-left">
               <ul class="pagination">
                  <li class="active"><span>1</span></li>
                  <li><a href="category&amp;path=33&amp;page=2.html">2</a></li>
                  <li><a href="category&amp;path=33&amp;page=3.html">3</a></li>
                  <li><a href="category&amp;path=33&amp;page=4.html">4</a></li>
                  <li><a href="category&amp;path=33&amp;page=2.html">&gt;</a></li>
                  <li><a href="category&amp;path=33&amp;page=4.html">&gt;|</a></li>
               </ul>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12 text-right category_pages_number">
               Showing 1 to 6 of 20 (4 Pages)					
            </div>
         </div>
      </div>
   </div>
</div>
<footer>

<?php
include 'footer.php';
?>