

<footer><div class="container footer_center">
    <div class="row">
       <div class="container footermodule">
 <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 atfooter1">
       <div class="promo-banner space5">
             <h4 class="footer-title footer_padding">Company</h4>
 <hr class="footer_border"><ul class="list-unstyled"><li><a href="javascript:void(0)">About Us</a></li>
    <li><a href="javascript:void(0)">Contact Us</a></li>
    <li><a href="javascript:void(0)">Privacy Policy</a></li>
    <li><a href="javascript:void(0)">Terms &amp; Conditions</a></li>
    <li><a href="javascript:void(0)">Support Centre</a></li>
 </ul></div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 atfooter2">
       <div class="promo-banner space5">
             <h4 class="footer-title footer_padding">Questions?</h4>
 <hr class="footer_border"><ul class="list-unstyled"><li><a href="javascript:void(0)">Help Support</a></li>
    <li><a href="javascript:void(0)">Track Order</a></li>
    <li><a href="javascript:void(0)">Return</a></li>
    <li><a href="javascript:void(0)">Shipping Info</a></li>
    <li><a href="javascript:void(0)">History</a></li>
 </ul></div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 atfooter3">
       <div class="promo-banner space5">
             <h4 class="footer-title footer_padding">Useful Links</h4>
 <hr class="footer_border"><ul class="list-unstyled"><li><a href="javascript:void(0)">Gift Cards</a></li>
    <li><a href="javascript:void(0)">Size Chart</a></li>
    <li><a href="javascript:void(0)">My Account</a></li>
    <li><a href="javascript:void(0)">Our Locations</a></li>
    <li><a href="javascript:void(0)">FAQs</a></li>
 </ul></div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 atfooter4">
       <div class="promo-banner space5">
             <h4 class="footer-title footer_padding">Connect With Us</h4>
 <hr class="footer_border"><div class="contact_footer">
    <div class="footer_icon">
       <a href="oc01.html"><i class="fa fa-facebook" aria-hidden="true"></i></a>
       <a href="oc01.html"><i class="fa fa-twitter" aria-hidden="true"></i></a>
       <a href="oc01.html"><i class="fa fa-instagram" aria-hidden="true"></i></a>
       <a href="oc01.html"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
       <a href="oc01.html"><i class="fa fa-youtube" aria-hidden="true"></i></a>
       <a href="oc01.html"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
       <a href="oc01.html"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
    </div>
 </div><br><div class="contact_footer">
    <div class="footer_icon">
       <div><i class="fa fa-paper-plane" aria-hidden="true"></i>123, Lorem Ipsum, India</div>
       <div><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@demo.com">info@demo.com</a></div>
       <div><i class="fa fa-phone" aria-hidden="true"></i><a href="tel:+1234567890">123 456 7890</a></div>
    </div>
 </div>         </div>
    </div>
 </div>
</div>      </div>
 </div>
 <div class="footer_bottom_outer">
    <div class="container">
       <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 footerbottom_link">
             <div class="card">
                <ul class="list-inline"><li><img class="img-responsive" src="images/cards-card-1.png" alt="Paypal"></li>
                   <li><img class="img-responsive" src="images/cards-card-2.png" alt="Discover"></li>
                   <li><img class="img-responsive" src="images/cards-card-3.png" alt="JBC"></li>
                   <li><img class="img-responsive" src="images/cards-card-4.png" alt="Amazon"></li>
                   <li><img class="img-responsive" src="images/cards-card-5.png" alt="Mastro"></li>
                   <li><img class="img-responsive" src="images/cards-card-6.png" alt="Master"></li>
                   <li><img class="img-responsive" src="images/cards-card-7.png" alt="Visa"></li>
                </ul></div>
          </div>
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
             <div class="copyright">
                <p>Minimal Store &copy; 2020. Made with  <i class="fa fa-heart"></i> by Multipurposethemes.</p>
             </div>
          </div>            
       </div>
    </div>
 </div>
</footer></body></html>
