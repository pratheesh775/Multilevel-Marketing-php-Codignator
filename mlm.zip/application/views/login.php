<?php
include 'header.php';
?>
<div class="container">
    <ul class="breadcrumb"><li><a><i class="fa fa-home"></i></a></li>
          <li><a>Account</a></li>
          <li><a>Login</a></li>
        </ul><div class="row">
        <div id="content" class="col-sm-12">   
          <h1>Login Account<br><?php echo @$message;?></h1>
        <form action="login" method="post" enctype="multipart/form-data" class="form-horizontal">
    
          <fieldset id="account"><legend>Please Enter Login Credentials</legend>
            <div class="form-group required" style="display: none;">
              <label class="col-sm-2 control-label">Customer Group</label>
              <div class="col-sm-10">
                                            <div class="radio">
                  <label>
                    <input type="radio" name="customer_group_id" value="1" checked>
                    Default</label>
                </div>
                                          </div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-firstname">Mobile Number</label>
              <div class="col-sm-10">
                <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" required type="number" name="mobileno" value="" placeholder="Mobile Number" id="input-firstname" class="form-control"></div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-lastname">Password</label>
              <div class="col-sm-10">
                <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" required type="password" name="password" value="" placeholder="password" id="input-lastname" class="form-control"></div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-email"></label>
              <div class="col-sm-10">
                <input type="submit" name="submit" value="Submit" class="btn btn-primary"  id="input-email" class=""></div>
            </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>

<?php
include 'footer.php';
?>