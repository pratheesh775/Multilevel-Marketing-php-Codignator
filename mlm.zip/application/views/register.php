<?php
include 'header.php';
?>
<div class="container">
    <ul class="breadcrumb"><li><a><i class="fa fa-home"></i></a></li>
          <li><a>Account</a></li>
          <li><a>Register</a></li>
        </ul><div class="row">                <div id="content" class="col-sm-12">      <h1>Register Account<br><?php echo @$message;?></h1>
        <p><a href="<?php echo base_url();?>login">If you already have an account with us, please login at the login page</a>.</p>
        <form method="post" enctype="multipart/form-data" class="form-horizontal">
          <fieldset id="account"><legend>Personal Details</legend>
            <div class="form-group required" style="display: none;">
              <label class="col-sm-2 control-label">Customer Group</label>
              <div class="col-sm-10">
                                            <div class="radio">
                  <label>
                    <input type="radio" name="customer_group_id" value="1" checked>
                    Default</label>
                </div>
                                          </div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-firstname">Full Name</label>
              <div class="col-sm-10">
                <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" required type="text" name="fullname" value="" placeholder="Full Name" id="input-firstname" class="form-control"></div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-email">E-Mail</label>
              <div class="col-sm-10">
                <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" required  type="email" name="email" value="" placeholder="E-Mail" id="input-email" class="form-control"></div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-telephone">Mobile</label>
              <div class="col-sm-10">
                <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" required  type="number" name="mobileno" value="" placeholder="Contact Number" id="input-telephone" class="form-control"></div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-fax">Adhar No</label>
              <div class="col-sm-10">
                <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" required  type="number" name="adhar" value="" placeholder="Adhar Number" id="input-fax" class="form-control"></div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-fax">Pan Card No</label>
              <div class="col-sm-10">
                <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" required  type="number" name="pancard" value="" placeholder="PAN Card Number" id="input-fax" class="form-control"></div>
            </div>
            
                    </fieldset><fieldset id="address"><legend>Address</legend>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-zone">Address</label>
              <div class="col-sm-10">
              <textarea pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" name="address" value="" placeholder="Address" id="input-fax" class="form-control" required></textarea></div>
            </div>
                    </fieldset>
                    
                    <fieldset id="address"><legend>Bank Details</legend>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-zone">Account Number</label>
              <div class="col-sm-10">
              <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" type="number" name="accountno" value="" placeholder="Account Number" id="input-fax" class="form-control" required></div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-zone">IFC Code</label>
              <div class="col-sm-10">
              <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" type="text" name="ifc" value="" 
              placeholder="IFC Code" id="input-fax" class="form-control" required></div>
            </div>
          
                    </fieldset>
                    <fieldset id="address"><legend>Other Details</legend>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-zone">Refferal ID</label>
              <div class="col-sm-10">
              <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" type="number" name="sponserid" value=""
               placeholder="User id of your Parent Account" id="input-fax" class="form-control" required></div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-zone">Nominate</label>
              <div class="col-sm-10">
              <input pattern="[^'\x22;\x22]+" title=" ' and ; NOT ALLOWED" type="name" name="nominate" value="" placeholder="Name of Nominate" id="input-fax" class="form-control" required></div>
            </div>
          
                    </fieldset>
                    
                    
                    
                    
                    <fieldset><legend>Your Password</legend>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-password">Password</label>
              <div class="col-sm-10">
                <input required  type="password" name="password" value="" placeholder="Password" id="input-password" class="form-control"></div>
            </div>
            

            
 


       <div class="buttons">
            <div class="pull-right">I have read and agree to the <a href="<?php echo base_url();?>policy" class="agree"><b>Privacy Policy</b></a>                        <input type="checkbox" id="checkme"/>
                          &nbsp;
                          <input type="submit" name="sendNewSms" class="btn btn-primary" disabled="disabled" id="sendNewSms" value=" Send " />

            <!---  <input type="submit" value="Continue" class="btn btn-primary">--->
           <br>
            </div>
              <script>
 var checker = document.getElementById('checkme');
 var sendbtn = document.getElementById('sendNewSms');
 // when unchecked or checked, run the function
 checker.onchange = function(){
if(this.checked){
    sendbtn.disabled = false;
} else {
    sendbtn.disabled = true;
}

}

</script>

          </div>
                </form>
        </div>
      </div>
  </div>
  <footer>
      <?php
      include 'footer.php';
      ?>