<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Password extends CI_Controller {
    
    public function __construct()
	{
	parent::__construct();
	$this->load->database();
    $this->load->database();
	$this->load->helper('file');
	$this->load->model('Wacfus');
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->library('upload');
    $this->load->helper(array('form', 'url'));
        $this->load->helper('form');
$this->load->library('email');
    }
    public function logout()
	{
        $this->session->unset_userdata('mobileno');
        $this->session->unset_userdata('password');
redirect(base_url().'login');
    }
    public function change()
	{
     
        if($this->input->post('submit'))
        {
             $no=$this->input->post('mobileno');
             $password=$this->input->post('password');
            $collagedata = [
                'password' => $password,
                   ];
            $this->db->where('mobileno',$no);
            $this->db->update('users',$collagedata);
            $this->session->unset_userdata('mobileno');
            $this->session->unset_userdata('password');
        $data['message']= "<p style=color:blue>Password changed Successfully...!</p>";
 $this->load->view('login',$data);
        //   redirect('password/logout');    
    }  
    else {
        
     
    $mobileno=$this->session->userdata('mobileno'); // Where item is the array index like session id
    $password=$this->session->userdata('password'); // Where item is the array index like session id  
   $data['result'] = $this->Wacfus->user_details($mobileno);   
   $data['result1'] = $this->Wacfus->chain_details($mobileno);   
   $this->load->view('changepassword',$data);
    }
    }
}
