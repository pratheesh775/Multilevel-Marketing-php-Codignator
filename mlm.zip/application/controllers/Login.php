<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    
    public function __construct()
	{
	parent::__construct();
	$this->load->database();
    $this->load->database();
	$this->load->helper('url');
   // $this->load->model('Wacfus');
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->helper('form');
    $this->load->library('email');
    }
    
    public function index()
	{
        if($this->input->post('submit')) // Where item is the array index like session id
        {

            $mobileno=$this->input->post('mobileno');
            $password=$this->input->post('password');
                      
            $where_array = array(
                'mobileno'=>$mobileno,'password'=>$password);
    $table_name = "users";
    $limit = 10;
    $offset = 0;
    $query = $this->db->get_where($table_name,$where_array, $limit, $offset);   
     if ($query->num_rows() > 0)
         {
       foreach ($query->result() as $row)
             {
                    $status=$row->status;
                          
             }
             if($status == 'No')
             {
                $this->session->set_userdata('mobileno', $mobileno);
                $this->session->set_userdata('password', $password);
                $data['message']="<p style=color:blue>Please Make a Parchase to enter your Dash Board!</p> ";
             }
             else
             {
                $this->session->set_userdata('mobileno', $mobileno);
                $this->session->set_userdata('password', $password);
                 redirect(base_url().'admin');
             }
            }
            else
            {
                $data['message']="<p style=color:blue>Authentication Error..!</p> ";
                
            }
        }
    
        else if($this->session->userdata('mobileno'))
        {
            $mobileno=$this->session->userdata('mobileno'); // Where item is the array index like session id
            $password=$this->session->userdata('password'); // Where item is the array index like session id  
        
        $where_array = array(
            'mobileno'=>$mobileno,'password'=>$password);
$table_name = "users";
$limit = 10;
$offset = 0;
$query = $this->db->get_where($table_name,$where_array, $limit, $offset);   
 if ($query->num_rows() > 0)
     {
   foreach ($query->result() as $row)
         {
                $status=$row->status;
                      
         }
         if($status == 'No')
         {
            $this->session->set_userdata('mobileno', $mobileno);
            $this->session->set_userdata('password', $password);
            $data['message']="<p style=color:blue>Please Make a Purchase to enter your Dash Board!</p> ";
         }
         else
         {
            $this->session->set_userdata('mobileno', $mobileno);
            $this->session->set_userdata('password', $password);
             redirect(base_url().'admin');
         }
        }
        else
        {
            $data['message']="<p style=color:blue>Authentication Error..!</p> ";
            
        }
    }

$data['a']="a";

        $this->load->view('login.php',$data);
}

}