<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
    
    public function __construct()
	{
	parent::__construct();
	$this->load->database();
    $this->load->database();
	$this->load->helper('url');
   // $this->load->model('Wacfus');
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->helper('form');
    $this->load->library('email');
    }
    
    public function index()
	{
        $data['a']="";
        if($this->input->post('sendNewSms'))
        {
            $fname=$this->input->post('fullname');
            $adress=$this->input->post('address');
            $email=$this->input->post('email');
            $pan=$this->input->post('pancard');
           $password=$this->input->post('password');
           $adhar=$this->input->post('adhar');
           $mobile=$this->input->post('mobileno');
           $sponser=$this->input->post('sponserid');
           $nominate=$this->input->post('nominate');
           $account=$this->input->post('accountno');
           $ifc=$this->input->post('ifc');
         'id'.  $id=$mobile-6999999999;

        $where_array = array(
            'mobileno'=>$mobile);
        $table_name = "users";
        $limit = 10;
        $offset = 0;
        $query = $this->db->get_where($table_name,$where_array, $limit, $offset);   
        if ($query->num_rows() > 0)
         {
            $data['message']="<p style=color:blue>This User already Exist..!</p> ";
        }
        else
        {
$data['message']="<p style=color:green>Succesfully Registered..!<br>Pleasse Login for get USER_ID</p> ";
     
$que=$this->db->query("insert into users values('','$id', '$fname', '$adress','$adhar', '$pan', '$mobile', '$email', '$sponser','$nominate', '$account', '$ifc','No','$password')");



        }
    }
        $this->load->view('register.php',$data);

    
    }   

}