<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Aboutus extends CI_Controller {
    
    public function __construct()
	{
	parent::__construct();
	$this->load->database();
    $this->load->database();
	$this->load->helper('url');
   // $this->load->model('Wacfus');
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->helper('form');
    $this->load->library('email');
    }
    
    public function index()
	{
        $this->load->view('aboutus.php');
}

}