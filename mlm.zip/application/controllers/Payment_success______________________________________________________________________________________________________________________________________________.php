<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment_success______________________________________________________________________________________________________________________________________________ extends CI_Controller {
    
    public function __construct()
	{
	parent::__construct();
    $this->load->dbforge();
    $this->load->database(); 
    $this->load->database();
	$this->load->helper('url');
   // $this->load->model('Wacfus');
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->helper('form');
    $this->load->library('email');
    }
    
    public function index()
	{
                  echo 'Date'.$datew=date('yy-m-d');
                                  
                                              
       echo $mobileno=$this->session->userdata('mobileno');
       echo $password=$this->session->userdata('password');
        
       $where_array = array(
        'mobileno'=>$mobileno,'password'=>$password);
$table_name = "users";
$limit = 10;
$offset = 0;
$query = $this->db->get_where($table_name,$where_array, $limit, $offset);   
if ($query->num_rows() > 0)
 {
     foreach ($query->result() as $row)
      {
        echo $parant=$row->parant;
        echo $userid=$row->userid;
    echo  $fname=$row->fullname;
    echo "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh.$userid";
    echo $que=$this->db->query("insert into payment_status values('$userid', '0', 'Not')");
    
  }
  //$this->load->view('aboutus.php');
}

//insert into payement status



$left='';
$right='';
          $where_array = array(
                    'user_id'=>$parant);
                    $table_name = "chain";
                    $limit = 10;
                    $offset = 0;
                    $query = $this->db->get_where($table_name,$where_array, $limit, $offset);   
                    if ($query->num_rows() > 0)
                            {
                                foreach ($query->result() as $row)
                                        {
                                            echo 'Left'.$left=$row->left_id;
                                            echo 'Right'.$right=$row->right_id;
                                            }
//$this->load->view('aboutus.php');
                            }
                            if($left == '')
                              {
                                $data = [
                                    'left_id' => $userid,
                                    'left_name' => $fname
                                ];
                                $this->db->where('user_id', $parant);
                                $this->db->update('chain', $data);
                              }
                        else if($right == '')
                        {
                                 
                                $data = [
                                    'right_id' => $userid,
                                    'right_name' => $fname
                                ];
                                $this->db->where('user_id', $parant);
                                $this->db->update('chain', $data);

                        }
                        $data = [
                            'status' => 'Yes'
                        ];
                        $this->db->where('userid', $userid);
                        $this->db->update('users', $data);

$que=$this->db->query("insert into chain values('','$userid', '$parant', '','', '', '$mobileno', '', '','$fname')");





















//$this->db->query('use Library');

// define table fields
$fields = array(
  'id' => array(
    'type' => 'INT',
    'constraint' => 9,
    'unsigned' => TRUE,
    'auto_increment' => TRUE
  ),
  'left_id' => array(
    'type' => 'VARCHAR',
    'constraint' => 30
  ),
  'right_id' => array(
    'type' => 'VARCHAR',
    'constraint' => 30
  ),
  'date' => array(
    'type' => 'VARCHAR',
    'constraint' => 30
  ),
   );
 $name='anytime'.$userid;
$this->dbforge->add_field($fields);

// define primary key
$this->dbforge->add_key('id', TRUE);

// create table
$this->dbforge->create_table($name);

//insert dynamic chain...

$puserid=$userid;

while( $userid != '2061797447' )
{


$where_array = array(
  'user_id'=>$userid);
  $table_name = "chain";
  $limit = 10;
  $offset = 0;
  $query = $this->db->get_where($table_name,$where_array, $limit, $offset);   
  if ($query->num_rows() > 0)
          {
              foreach ($query->result() as $row)
                      {
                 echo $parant=$row->parant_id;
                 echo $left=$row->left_id;
                 echo $right=$row->right_id;
                }
                        }
                        
                        $where_array = array(
                          'user_id'=>$parant);
                          $table_name = "chain";
                          $limit = 10;
                          $offset = 0;
                          $query = $this->db->get_where($table_name,$where_array, $limit, $offset);   
                          if ($query->num_rows() > 0)
                                  {
                                      foreach ($query->result() as $row)
                                              {
                                                if($row->left_id == $userid)
                                                  $que=$this->db->query("insert into `anytime$parant`  values('','$puserid', '0','$datew')");
                                                if($row->right_id == $userid)
                                                $que=$this->db->query("insert into `anytime$parant`  values('', '0', '$puserid','$datew')");
                                               echo 'parant_id'.$row->parant_id;
                                                 }
                                                }
                                         $userid=$parant;
                                              }





//$where_array = array(
  //  'user_id' <> 0 );
    //$table_name = "users";
   // $limit = 10;
    //$offset = 0;
    //$query = $this->db->get_where($table_name,$where_array, $limit, $offset);   
    //if ($query->num_rows() > 0)
     //       {
       //         foreach ($query->result() as $row)
         ////               {
             //               echo 'Left'.$left=$row->left_id;
               //v//             echo 'Right'.$right=$row->right_id;
                 //           }
//$this->load->view('aboutus.php');
 //           }
















//redirect(base_url().'login');

}
}