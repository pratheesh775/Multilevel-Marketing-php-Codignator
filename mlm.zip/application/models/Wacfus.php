<?php
class Wacfus extends CI_Model 
{
    function chain_details($mobileno)
    {
        $query=$this->db->query("select * from chain");
        return $query->result();
    }
    
    function user_details($no)
	{
        $query=$this->db->query("select * from users where mobileno=$no");
        return $query->result();
            
    }
    public function newleft($id)
    {
        $query = $this->db->query("SELECT * FROM `anytime$id` where right_id=0 ORDER BY id DESC LIMIT 4");
        $result = $query->result_array();
        return $query->result();
        }
    public function newright($id)
    {
        $query = $this->db->query("SELECT * FROM `anytime$id` where left_id=0 ORDER BY id DESC LIMIT 4");
        $result = $query->result_array();
        return $query->result();
        }
  
        public function chainview($id)
        {
            $query = $this->db->query("SELECT * FROM chain where user_id in (select left_id from `anytime$id`)");
            $result = $query->result_array();
            return $query->result();
            }
            public function chainviewr($id)
            {
                $query = $this->db->query("SELECT * FROM chain where user_id in (select right_id from `anytime$id`)");
                $result = $query->result_array();
                return $query->result();
                }
                public function cash($id)
                {
                    $query = $this->db->query("select * from `anytime$id`");
                    $result = $query->result_array();
                    return $query->result();
                    }
    
        
}